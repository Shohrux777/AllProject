<template>
  <div class="d-flex justify-content-center w-100">
    <img src="../assets/animate.gif" width="60px" class="img-fluid" alt="">
  </div>
</template>


