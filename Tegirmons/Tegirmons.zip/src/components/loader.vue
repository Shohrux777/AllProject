<template>
  <div style="position: absolute; top:0; left:0; right:0; bottom:0; background: rgba(255,255,255,0.7); z-index:1111111111111111;" class="d-flex justify-content-center align-items-center ">
    <img src="../assets/animate.gif" width="80px" class="img-fluid" alt="">
  </div>
</template>