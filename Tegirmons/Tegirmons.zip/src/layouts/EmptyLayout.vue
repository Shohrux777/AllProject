<template>
  <div>
    <div style="">
      <router-view/>
    </div>
  </div>
</template>

<script>

  export default {
    name: "empty",

  };
</script>


