<?php $__env->startSection('title', 'Bosh sahifa'); ?>
<!-- <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script> -->

<?php $__env->startSection('content'); ?>
<div class="categoryID py-5 container">
    <div class="row">
        <div class="item col-12 col-sm-12 col-md-4 col-lg-3 ">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="px-3 py-2 a_hover d-block border text-dark" href="<?php echo e(route('categoryId', $category->id)); ?>"> <?php echo e($category->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-12 col-sm-12 col-md-8 col-lg-9">
            <div class="row row_contents books_items p-0 m-0 mt-4 w-100">
                <?php if(count($books_category)>0): ?>
                    <?php $__currentLoopData = $books_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="books_item col-12 col-sm-12 col-md-6 col-lg-4">
                            <div class="note_item">
                                <a href="<?php echo e(route('bookId', $book->id)); ?>" class="w-100 d-flex justify-content-center">
                                    <img src="<?php echo e(asset('/storage/images/picture/' .$book->image)); ?>" class="img-fluid rounded shadow" style="width: 90%;">
                                </a>
                                <div class="tex_boxx">
                                    <a href="<?php echo e(route('bookId', $book->id)); ?>"><p><?php echo e($book->name); ?></p></a>
                                    <a href="<?php echo e(route('bookId', $book->id)); ?>"><h5><?php echo e($book->writer); ?></h5></a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div class="text-center">
                    <h5>Kitob topilmadi</h5>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<style>
    .a_hover:hover{
        background: rgb(113, 198, 255);
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\111\Downloads\example-app\resources\views/categoryShow.blade.php ENDPATH**/ ?>