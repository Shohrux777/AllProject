<?php $__env->startSection('title', 'Kitoblar'); ?>

<?php $__env->startSection('content'); ?>
    <header class="page-header">
        <h2>Kitoblar</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="index.html">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Kitoblar</span></li>
            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    <div class="panel-actions">
                        <a href="#" class="fa fa-caret-down"></a>
                        <!-- <a href="#" class="fa fa-times"></a> -->
                    </div>
                    <h2 class="panel-title">Kitoblar</h2>
                </header>
                <?php if(Session::has('alert-success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(Session::get('alert-success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(Session::has('alert-info')): ?>
                    <div class="alert alert-info" role="alert">
                        <?php echo e(Session::get('alert-info')); ?>

                    </div>
                <?php endif; ?>
                <?php if(Session::has('server_error')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(Session::get('server_error')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="panel-body">
                    <form class="form-horizontal form-bordered"  method="post" action="<?php echo e(route('book_update')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>"
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="inputDefault1">Kitob nomi</label>
                            <div class="col-md-6">
                                <input type="text" name="name" value="<?php echo e($book->name); ?>" class="form-control" id="inputDefault1">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="inputSuccess1">Kategoriya</label>
                            <div class="col-md-6">
                                <select name="category_id" class="form-control input-md mb-md" id="inputSuccess1">
                                    <option value="<?php echo e($book->category_id); ?>" selected><?php echo e($book->category_name); ?></option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="inputDefault2">Muallif</label>
                            <div class="col-md-6">
                                <input type="text" name="writer" value="<?php echo e($book->writer); ?>" class="form-control" id="inputDefault2">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="inputDefault3">Til</label>
                            <div class="col-md-6">
                                <input type="text" name="lang" value="<?php echo e($book->lang); ?>" class="form-control" id="inputDefault3">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="inputDefault4">Nashriyot</label>
                            <div class="col-md-6">
                                <input type="text" name="publisher" value="<?php echo e($book->publisher); ?>" class="form-control" id="inputDefault4">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="inputDefault5">Nashr yili</label>
                            <div class="col-md-6">
                                <input type="text" name="title" value="<?php echo e($book->title); ?>" class="form-control" id="inputDefault5">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="inputDefault6">Rasm</label>
                            <div class="col-md-6">
                                <input type="file" name="image" value="<?php echo e($book->image); ?>" class="form-control" id="inputDefault6">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="inputDefault7">Kitob pdf</label>
                            <div class="col-md-6">
                                <input type="file" name="pdf" value="<?php echo e($book->pdf); ?>" class="form-control" id="inputDefault7">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="textareaDefault1">Kitob haqida</label>
                            <div class="col-md-6">
                                <textarea class="form-control" name="note" rows="4" id="textareaDefault1"><?php echo e($book->note); ?></textarea>
                            </div>
                        </div>
                        <div class=" text-right">
                            <button type="submit" style="font-size: 12px;" class="mb-xs mt-xs mr-xs btn btn-success">Tahrirlash</button>
                        </div>
                    </form>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\111\Downloads\example-app\resources\views/bookEdit.blade.php ENDPATH**/ ?>