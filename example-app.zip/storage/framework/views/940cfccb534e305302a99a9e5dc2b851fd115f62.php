<?php $__env->startSection('title', 'Bosh sahifa'); ?>
<!-- <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script> -->

<?php $__env->startSection('content'); ?>
<div class="categoryID py-5 container">
    <div class="container">
        <img src="<?php echo e(asset('/storage/news/picture/' .$new_id->image)); ?>" class="img-fluid rounded" style="width: 100%; max-height:580px;">
    </div>
    <div class="container mt-4">
        <div class="text-center">
            <h2 style="font-weight: bold;">
                <?php echo e($new_id->name); ?>

            </h2>
        </div>

    </div>
    <section class="py-2 px-2">
        <div class="m-0 py-2 px-3" style="box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
            <p>
                <?php echo e($new_id->text); ?>

            </p>
        </div>
    </section>

    <section class="py-2 px-2">
        <div class="text-center">
            <a class="text-primary" href="<?php echo e($new_id->link); ?>"><?php echo e($new_id->link); ?></a>
        </div>
    </section>
</div>
<style>
    .a_hover:hover{
        background: rgb(113, 198, 255);
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\111\Downloads\example-app\resources\views/newsShow.blade.php ENDPATH**/ ?>