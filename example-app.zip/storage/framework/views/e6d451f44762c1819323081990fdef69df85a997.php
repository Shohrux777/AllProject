<?php $__env->startSection('title', 'Yangiliklar'); ?>

<?php $__env->startSection('content'); ?>
    <header class="page-header">
        <h2>Yangiliklar</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="index.html">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Yangiliklar</span></li>
            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    <div class="panel-actions">
                        <a href="#" class="fa fa-caret-down"></a>
                        <!-- <a href="#" class="fa fa-times"></a> -->
                    </div>
                    <h2 class="panel-title">Yangiliklar</h2>
                </header>
                <?php if(Session::has('alert-success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(Session::get('alert-success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(Session::has('alert-info')): ?>
                    <div class="alert alert-info" role="alert">
                        <?php echo e(Session::get('alert-info')); ?>

                    </div>
                <?php endif; ?>
                <?php if(Session::has('server_error')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(Session::get('server_error')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="panel-body">
                    <form class="form-horizontal form-bordered"  method="post" action="<?php echo e(route('news_update')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="new_id" value="<?php echo e($new->id); ?>"
                    <div class="form-group">
                        <label class="col-md-3 control-label" for="inputDefault1">Yangilik mavzusi</label>
                        <div class="col-md-6">
                            <input type="text" value="<?php echo e($new->name); ?>" name="name" class="form-control" id="inputDefault1">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label" for="inputDefault2">Sana</label>
                        <div class="col-md-6">
                            <input type="text" value="<?php echo e($new->date); ?>" name="date" class="form-control" placeholder="dd-mm-yyyy" id="inputDefault2">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 control-label" for="inputDefault4">Link</label>
                        <div class="col-md-6">
                            <input type="text" name="link" value="<?php echo e($new->link); ?>" class="form-control" id="inputDefault4">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label" for="inputDefault6">Rasm</label>
                        <div class="col-md-6">
                            <input type="file" name="image" value="<?php echo e($new->image); ?>" class="form-control" id="inputDefault6">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label" for="textareaDefault1">Yangilik</label>
                        <div class="col-md-6">
                            <textarea class="form-control" name="text" rows="4" id="textareaDefault1"><?php echo e($new->text); ?></textarea>
                        </div>
                    </div>
                        <div class=" text-right">
                            <button type="submit" style="font-size: 12px;" class="mb-xs mt-xs mr-xs btn btn-success">Tahrirlash</button>
                        </div>
                    </form>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\111\Downloads\example-app\resources\views/newsEdit.blade.php ENDPATH**/ ?>