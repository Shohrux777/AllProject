<?php $__env->startSection('title', 'Kategoriya'); ?>

<?php $__env->startSection('content'); ?>
    <header class="page-header">
        <h2>Kategoriya</h2>
        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="index.html">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Kategoriyani tahrirlash</span></li>
            </ol>
            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    <div class="panel-actions">
                        <a href="#" class="fa fa-caret-down"></a>
                        <!-- <a href="#" class="fa fa-times"></a> -->
                    </div>
                    <h2 class="panel-title">Kategoriya</h2>
                </header>
                <?php if(Session::has('alert-success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(Session::get('alert-success')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="panel-body">
                    <form class="form-horizontal form-bordered" method="post" action="<?php echo e(route('category_update')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="category_id" value="<?php echo e($category->id); ?>"
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="inputDefault">Kategoriya</label>
                            <div class="col-md-6">
                                <input type="text" name="name" value="<?php echo e($category->name); ?>" class="form-control" id="inputDefault">
                            </div>
                        </div>
                        <div class=" text-right">
                            <button type="submit" style="font-size: 12px;" class="mb-xs mt-xs mr-xs btn btn-success">Saqlash</button>
                        </div>
                    </form>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\111\Downloads\example-app\resources\views/bookCategoryEdit.blade.php ENDPATH**/ ?>