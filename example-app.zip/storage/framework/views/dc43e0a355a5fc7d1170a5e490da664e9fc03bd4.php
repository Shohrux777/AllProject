<?php $__env->startSection('title', 'Kitob buyurtmasi'); ?>

<?php $__env->startSection('content'); ?>
<header class="page-header">
        <h2>Kitob buyurmalar</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="index.html">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Kitob buyurmalar</span></li>
            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>

    </header>
    <section class="panel">
        <header class="panel-heading bg-info">
            <div class="panel-actions">
                <a href="#" class="fa fa-caret-down"></a>
                <!-- <a href="#" class="fa fa-times"></a> -->
            </div>

            <h2 class="panel-title">Buyurtma List</h2>
        </header>
        <div class="panel-body">
        <div class="panel-body">
            <div class="table-responsive">
                <table class="table mb-none">
                    <thead>
                        <tr>
                            <th>№</th>
                            <th>FIO</th>
                            <th>Tel</th>
                            <th>Kitob nomi</th>
                            <th>Muallif</th>
                            <th>Nashr etilgan yili</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($buyurtmas)>0): ?>
                            <?php $__currentLoopData = $buyurtmas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyurtma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($buyurtma->id); ?></td>
                                <td><?php echo e($buyurtma->name); ?></td>
                                <td><?php echo e($buyurtma->tel); ?></td>
                                <td><?php echo e($buyurtma->b_name); ?></td>
                                <td><?php echo e($buyurtma->creator); ?></td>
                                <td><?php echo e($buyurtma->year); ?></td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php else: ?>
                            <h5>Buyurtma hali qo'shilmagan</h5>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\111\Downloads\example-app\resources\views/bookReceive.blade.php ENDPATH**/ ?>